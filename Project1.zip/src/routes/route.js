
const express = require('express');
const router = express.Router();
const blogController = require("../controller/blogController");
const authorController = require('../controller/authorController');

router.post("/createAuthor",authorController.createAuthor)
router.post("/createBlog",blogController.createBlog)
router.get("/getBlog",blogController.getBlogs)
router.put("/updateBlog/:blogId",blogController.updateBlog)
router.delete("/deleteBlog/:blogId",blogController.deleteBlogByBlogId)
router.delete("/deleteBlogByParams",blogController.deleteBlogByParam)
//router.post("/createBlog",blogController.createBlogs)







module.exports = router;