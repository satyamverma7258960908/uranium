const mongoose = require('mongoose');
const authorModel = require('../Models/authorModel');
//const authorModel = require("../Models/AuthorModel")
const blogModel = require('../Models/BlogModel')


//CREATE BLOG THIRD API---------------------2
const createBlog = async function (req, res) {
    try {
         const requestBody = req.body;

        // FIND AUTHORID BY AUTHOR MODEL
        const author = await authorModel.findById(requestBody.authorId);
        // NOT VALID AUTHOR ID
        if (!author) {
            res.status(400).send({ status: false, message: `Author does not exit` })
            return
        }
                // CREATE BLOG
                const newBlog = await blogModel.create(requestBody)
                res.status(201).send({ status: true, message: 'New blog created successfully', data: newBlog })
            } catch (error) {
                console.log(error)
                res.status(500).send({ status: false, message: error.message });
            }
        }

        // const createBlogs= async function(req, res){

        //     let data=req.body
        
        //     let Author= await authorModel.findById(data.authorId)
        //     if(!Author)
        //     {
        //         res.status(400).send({status:false, message:"Author_Id not found"})
        //     }else
        //     {
        //        let savedblog=await blogModel.create(data)
        //        res.status(201).send({status:true,data:savedblog})
        //     }
        // }


        
// const getBlogs= async function(req, res){
    // try{     
        // let info = req.query
        // if(info){
        //   let data = await blogModel.find({$and:[{isDeleted:false},{ispublished:true},info]})
        //   if(data){
        //     res.status(200).send({msg:data})
        //   }else{
        //     res.status(404).send({msg:"no such blog"})
        //   }
        // }else{
        // let  data = await blogModel.find({$and:[{isDeleted:false},{ispublished:true}]}) 
        // if(data){
        //   res.status(200).send({msg:data})
        // }else{
        //   res.status(404).send({msg:"no such blog"})
        // } 
        // } 
        // if(data){
        //   res.status(200).send({msg:data})
        // }else{
        //   res.status(404).send({msg:"no such blog"})
        // }
        // console.log("Data", data)
        // if (data){
        //     if (data.isDeleted == false && data.isPublished == true){
        //         res.status(200).send({Status: "Success", Info: data })
        //     }           
        //     else{
        //         res.status(500).send({err: "either book isn't published or data is deleted"})
        //     }
        // }
        // else{
        //     res.status(404).send({err: "provide an valid Input details"})
        // }  
    // }
    // catch(err) {
    //     console.log(err.message)
    //     res.status(500).send( { msg: "Something went wrong" } )
    // }
   // }
   const getBlogs = async (req,res) => {
    try{
        req.query.isDeleted = false
        req.query.isPublished = true
        let filter = await blogModel.find(req.query)
        if(!(filter.length>0))
        return res.status(404).send({status: false, msg: "No such documents found"})
        res.status(200).send({status: true, data: filter})
    }
    catch(err){
        console.log(err.message)
        res.status(500).send({status: false, msg: err.message})
    }
}




let updateBlog = async function(req,res){
  let blogId=req.params.blogId
  let content = req.body
  let blog = await blogModel.findOne({$and:[{_id:blogId},{isDeleted:false}]})
  if(!blog){
    res.status(404).send({msg:"sorry dear we dont have such blog in our record"})
  }
  let updatedBlog=await blogModel.findOneAndUpdate({_id:blogId},{$set:content},{returnDocument:"after"})
  res.status(200).send({data:updatedBlog}) 
}

let deleteBlogByBlogId = async function(req,res){
  let blogId = req.params.blogId
  let blog = await blogModel.findOne({$and:[{_id:blogId},{isDeleted:false}]})
  if(!blog){
    return res.status(404).send("no such blog in our record")
  }
  await blogModel.findOneAndUpdate({_id:blogId},{$set:{"isDeleted":true}})
  res.sendStatus(200);
}

let deleteBlogByParam = async function(req,res){
  let criteria = req.query
  let blog = await blogModel.findOne(criteria)
  if(!blog){
    res.status(404).send({msg:"no such blog"})
  }
  await blogModel.remove(criteria)  
}



module.exports.createBlog=createBlog
//module.exports.createBlogs=createBlogs
module.exports.getBlogs=getBlogs
module.exports.updateBlog =  updateBlog
module.exports.deleteBlogByBlogId = deleteBlogByBlogId
module.exports.deleteBlogByParam = deleteBlogByParam


        