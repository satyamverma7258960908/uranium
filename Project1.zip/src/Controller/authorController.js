const AuthorModel = require("../Models/authorModel")
//const jwt = require('jsonwebtoken')

const createAuthor = async function (req, res) {
    try {
        let author = req.body
        let authorCreated = await AuthorModel.create(author)
        res.status(201).send({ data: authorCreated ,msg:"Author created successfully"})
    }
    catch (error) {
        console.log(error)
        res.status(500).send(error.message)
    }
}


module.exports.createAuthor=createAuthor